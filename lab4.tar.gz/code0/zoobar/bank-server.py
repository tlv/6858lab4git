#!/usr/bin/python

import rpclib
import sys
import bank
from debug import *
import auth_client

class BankRpcServer(rpclib.RpcServer):

    def rpc_transfer(self, sender, token, recipient, zoobars):
        if auth_client.check_token(sender, token):
            bank.transfer(sender, recipient, zoobars)

    def rpc_balance(self, username):
        return bank.balance(username)

    def rpc_add_user(self, username):
        bank.add_user(username)


(_, dummy_zookld_fd, sockpath) = sys.argv

s = BankRpcServer()
s.run_sockpath_fork(sockpath)
