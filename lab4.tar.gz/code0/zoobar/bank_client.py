from debug import *
import rpclib
import bank

def transfer(sender, token, recipient, zoobars):
    with rpclib.client_connect('/banksvc/sock') as c:
        return c.call('transfer', sender=sender, token=token, recipient=recipient, zoobars=zoobars)

def balance(username):
    with rpclib.client_connect('/banksvc/sock') as c:
        return c.call('balance', username=username)

def add_user(username):
    with rpclib.client_connect('/banksvc/sock') as c:
        return c.call('add_user', username=username)

def get_log(username):
    return bank.get_log(username)
