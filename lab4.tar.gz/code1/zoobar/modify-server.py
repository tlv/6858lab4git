#!/usr/bin/python

import auth_client
import rpclib
import sys
from debug import *
import zoodb

class ModifyProfileRPCServer(rpclib.RpcServer):

    def rpc_modify(self, username, token, pcode):
        if (auth_client.check_token(username, token)):
            profiledb = zoodb.profile_setup() 
            person = profiledb.query(zoodb.Profile).get(username)
            person.profile = pcode
            profiledb.commit()
        return

    def rpc_get_profile(self, username):
        profiledb = zoodb.profile_setup() 
        person = profiledb.query(zoodb.Profile).get(username)
        return person.profile

    def rpc_new_profile(self, username):
        log("executing new profile")
        profiledb = zoodb.profile_setup()
        newprofile = zoodb.Profile()
        newprofile.username = username
        profiledb.add(newprofile)
        log("about to commit")
        profiledb.commit()
        log("commited")
        return

(_, dummy_zookld_fd, sockpath) = sys.argv

s = ModifyProfileRPCServer()
s.run_sockpath_fork(sockpath)
