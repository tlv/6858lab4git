from debug import *
from zoodb import *
import rpclib

def transfer(username, token, target, zoobars):
    with rpclib.client_connect('/banksvc/sock') as c:
        c.call('transfer', username=username, token=token, target=target, zoobars=zoobars)
        return

def register(username):
    with rpclib.client_connect('/banksvc/sock') as c:
        c.call('register', username=username)
        return
    
def balance(username):
    with rpclib.client_connect('/banksvc/sock') as c:
        balance = c.call('balance', username=username)
        return balance

def get_log(username):
    with rpclib.client_connect('/banksvc/sock') as c:
        log = c.call('get_log', username=username)
        return log
