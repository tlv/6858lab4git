#!/usr/bin/python

import base64
import rpclib
import sys
import os
import sandboxlib
import urllib
import hashlib
import socket
import bank_client
import zoodb
import bank
import modify_client

from debug import *

## Cache packages that the sandboxed code might want to import
import time
import errno

class ProfileAPIServer(rpclib.RpcServer):
    def __init__(self, user, token, visitor):
        
        os.setresgid(66010, 66010, 66010)
        os.setgroups([63000, 61001, 64000, 65000])
        os.setresuid(66011, 66011, 66011)

        self.user = user
        self.token = token
        self.visitor = visitor

    def rpc_get_self(self):
        return self.user

    def rpc_get_visitor(self):
        return self.visitor

    def rpc_get_xfers(self, username):
        xfers = []
        for xfer in bank_client.get_log(username):
            xfers.append({ 'sender': xfer['sender'],
                           'recipient': xfer['recipient'],
                           'amount': xfer['amount'],
                           'time': xfer['time'],
                         })
        return xfers

    def rpc_get_user_info(self, username):
        person_db = zoodb.person_setup()
        p = person_db.query(zoodb.Person).get(username)
        if not p:
            return None
        return { 'username': p.username,
                 'profile': modify_client.get_profile(username),
                 'zoobars': bank_client.balance(username),
               }

    def rpc_xfer(self, target, zoobars):
        bank_client.transfer(self.user, self.token, target, zoobars)

def run_profile(pcode, profile_api_client):
    globals = {'api': profile_api_client}
    exec pcode in globals

class ProfileServer(rpclib.RpcServer):
    def rpc_run(self, user, visitor):
        uid = 67000

        profile_db = zoodb.profile_setup()
        profile_person = profile_db.query(zoodb.Profile).get(user)
        pcode = profile_person.profile.encode('ascii', 'ignore')
        pcode = pcode.replace('\r\n', '\n')

        userdir = '/' + base64.urlsafe_b64encode(user)
        if(not os.path.isdir(userdir)):
            os.mkdir(userdir)
            os.chown(userdir, 67000, 66011)

        db = zoodb.cred_setup()
        person = db.query(zoodb.Cred).get(user)
        token = person.token

        (sa, sb) = socket.socketpair(socket.AF_UNIX, socket.SOCK_STREAM, 0)
        pid = os.fork()
        if pid == 0:
            if os.fork() <= 0:
                sa.close()
                ProfileAPIServer(user, token, visitor).run_sock(sb)
                sys.exit(0)
            else:
                sys.exit(0)
        sb.close()
        os.waitpid(pid, 0)

        sandbox = sandboxlib.Sandbox(userdir, uid, '/profilesvc/lockfile')
        with rpclib.RpcClient(sa) as profile_api_client:
            return sandbox.run(lambda: run_profile(pcode, profile_api_client))

(_, dummy_zookld_fd, sockpath) = sys.argv

s = ProfileServer()
s.run_sockpath_fork(sockpath)
