from debug import *
from zoodb import *
import rpclib

def modify(username, token, pcode):
    with rpclib.client_connect('/modifysvc/sock') as c:
        c.call('modify', username=username, token=token, pcode=pcode)
        return
    
def get_profile(username):
    with rpclib.client_connect('/modifysvc/sock') as c:
        profile = c.call('get_profile', username=username)
        return profile

def new_profile(username):
    log("calling new profile")
    with rpclib.client_connect('/modifysvc/sock') as c:
        c.call('new_profile', username=username)
        return
