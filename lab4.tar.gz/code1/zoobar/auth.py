from zoodb import *
from debug import *

import hashlib
import random
import pbkdf2
import os
import binascii
import modify_client

def newtoken(db, person):
    hashinput = "%s%.10f" % (person.password, random.random())
    person.token = hashlib.md5(hashinput).hexdigest()
    db.commit()
    return person.token

def login(username, password):
    db = cred_setup()
    person = db.query(Cred).get(username)
    if not person:
        return None
    if pbkdf2.PBKDF2(password, person.salt).hexread(32) == person.password:
        return newtoken(db, person)
    else:
        return None

def register(username, password):
    db = person_setup()
    person = db.query(Person).get(username)
    if person:
        return None
    newperson = Person()
    newperson.username = username
    db.add(newperson)
    db.commit()

    log("Going to modify client")
    modify_client.new_profile(username)    
    log("Modified client")

    salt = binascii.b2a_hex(os.urandom(16))
    pwhash = pbkdf2.PBKDF2(password, salt).hexread(32)

    creddb = cred_setup()
    credperson = creddb.query(Cred).get(username)
    if credperson:
        return None
    newcredperson = Cred()
    newcredperson.username = username
    newcredperson.password = pwhash
    newcredperson.salt = salt
    creddb.add(newcredperson)
    creddb.commit()

    return newtoken(creddb, newcredperson)

def check_token(username, token):
    db = cred_setup()
    person = db.query(Cred).get(username)
    if person and person.token == token:
        return True
    else:
        return False

