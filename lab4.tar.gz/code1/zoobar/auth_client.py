from debug import *
from zoodb import *
import rpclib

def login(username, password):
    with rpclib.client_connect('/authsvc/sock') as c:
        cookie = c.call('login', username=username, password=password)
        return cookie

def register(username, password):
    with rpclib.client_connect('/authsvc/sock') as c:
        cookie = c.call('register', username=username, password=password)
        log("Got cookie")
        return cookie

def check_token(username, token):
    with rpclib.client_connect('/authsvc/sock') as c:
        authorized = c.call('checktoken', username=username, token=token)
        return authorized

